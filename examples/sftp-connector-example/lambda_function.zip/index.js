const { TransferClient, StartFileTransferCommand, ListFileTransferResultsCommand } = require('@aws-sdk/client-transfer');
const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');

const transfer = new TransferClient();
const secrets = new SecretsManagerClient();

exports.handler = async (event) => {
  console.log('=== SFTP TRANSFER LAMBDA START ===');
  console.log('Received event:', JSON.stringify(event, null, 2));
  
  try {
    const bucket = event.detail.bucket.name;
    const key = event.detail.object.key;
    
    console.log(`Processing file: s3://${bucket}/${key}`);
    console.log(`Connector ID: ${process.env.CONNECTOR_ID}`);
    console.log(`Remote Path: ${process.env.REMOTE_PATH}`);
    
    // Only process files from the test upload bucket
    if (bucket !== 'aws-ia-eel-test-upload-bucket') {
      console.log(`SKIPPING: File from bucket: ${bucket} (not test upload bucket)`);
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: 'File ignored - not from test upload bucket'
        })
      };
    }
    
    // Extract just the filename for the remote path
    const filename = key.split('/').pop();
    const remotePath = process.env.REMOTE_PATH ? `${process.env.REMOTE_PATH}/${filename}` : `/${filename}`;
    
    // The local path should be the S3 key from the source bucket
    const localPath = key.startsWith('/') ? key : `/${key}`;
    
    console.log(`Local path: ${localPath}`);
    console.log(`Remote path: ${remotePath}`);
    console.log(`Filename: ${filename}`);
    
    // Start file transfer using the connector
    const params = {
      ConnectorId: process.env.CONNECTOR_ID,
      SendFilePaths: [
        `${localPath}:${remotePath}`
      ]
    };
    
    console.log('=== STARTING FILE TRANSFER ===');
    console.log('Transfer params:', JSON.stringify(params, null, 2));
    
    const command = new StartFileTransferCommand(params);
    const result = await transfer.send(command);
    
    console.log('=== TRANSFER INITIATED SUCCESSFULLY ===');
    console.log('Transfer result:', JSON.stringify(result, null, 2));
    console.log(`Transfer ID: ${result.TransferId}`);
    
    // Wait a moment and check transfer status
    console.log('=== CHECKING TRANSFER STATUS ===');
    await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
    
    try {
      const statusCommand = new ListFileTransferResultsCommand({
        ConnectorId: process.env.CONNECTOR_ID,
        TransferId: result.TransferId
      });
      const statusResult = await transfer.send(statusCommand);
      console.log('Transfer status:', JSON.stringify(statusResult, null, 2));
    } catch (statusError) {
      console.log('Could not get transfer status (this is normal for new transfers):', statusError.message);
    }
    
    console.log('=== LAMBDA EXECUTION COMPLETE ===');
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'File transfer initiated successfully',
        transferId: result.TransferId,
        localPath: localPath,
        remotePath: remotePath,
        filename: filename
      })
    };
  } catch (error) {
    console.error('=== ERROR OCCURRED ===');
    console.error('Error processing file:', error);
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    console.error('Full error details:', JSON.stringify(error, null, 2));
    throw error;
  }
};
