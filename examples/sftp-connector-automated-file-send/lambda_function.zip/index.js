const { TransferClient, StartFileTransferCommand } = require('@aws-sdk/client-transfer');

const transferClient = new TransferClient();

exports.handler = async (event) => {
  const sourceBucket = event.detail.bucket.name;
  const sourceKey = event.detail.object.key;
  
  const command = new StartFileTransferCommand({
    ConnectorId: process.env.CONNECTOR_ID,
    SendFilePaths: [`/${sourceBucket}/${sourceKey}`]
  });
  
  const result = await transferClient.send(command);
  console.log('Transfer started:', result.TransferId);
  
  return { statusCode: 200, body: 'Transfer initiated' };
};
